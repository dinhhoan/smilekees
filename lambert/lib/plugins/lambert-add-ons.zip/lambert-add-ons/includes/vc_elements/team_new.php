<?php 
/* add_ons_php */
vc_map( array(
   "name"      => __("Our Team (NEW)", 'lambert-add-ons'),
   "description" => __("Our Team",'lambert-add-ons'),
   "base"      => "cth_team",
   "icon"                     => BBT_DIR_URL . "/assets/cththemes-logo.png",
   "category"=>'Lambert Old',
   "params"    => array(
        array(
            "type"      => "textfield",
            "holder"    => "div",
            "class"     => "",
            "heading"   => __("Count", 'lambert-add-ons'),
            "param_name"=> "count",
            "value"     => "4",
            "description" => __("Number of member to show", 'lambert-add-ons')
        ),
        array(
            "type" => "dropdown",
            "class"=>"",
            "heading" => __('Columns Grid', 'lambert-add-ons'),
            "param_name" => "columns",
            "value" => array(   
                __('One Column', 'lambert-add-ons') => '1',  
                __('Two Columns', 'lambert-add-ons') => '2',  
                __('Three Columns', 'lambert-add-ons') => '3',       
                __('Four Columns', 'lambert-add-ons') => '4',  
                __('Five Columns', 'lambert-add-ons') => '5',  
                __('Six Columns', 'lambert-add-ons') => '6',  
            ),
            "description" => __("Columns Grid", 'lambert-add-ons'),  
            "default"=>'4',    
        ),
        array(
            "type" => "dropdown",
            "class"=>"",
            "heading" => __('Order by', 'lambert-add-ons'),
            "param_name" => "order_by",
            "value" => array(   
                __('Date', 'lambert-add-ons') => 'date',  
                __('ID', 'lambert-add-ons') => 'ID',  
                __('Author', 'lambert-add-ons') => 'author',       
                __('Title', 'lambert-add-ons') => 'title',  
                __('Modified', 'lambert-add-ons') => 'modified',  
            ),
            "description" => __("Order by", 'lambert-add-ons'),  
            "default"=>'date',    
        ),
        array(
            "type" => "dropdown",
            "class"=>"",
            "heading" => __('Order', 'lambert-add-ons'),
            "param_name" => "order",
            "value" => array(   
                            __('Descending', 'lambert-add-ons') => 'DESC',
                            __('Ascending', 'lambert-add-ons') => 'ASC',  
                                                                                                              
                            ),
            "description" => __("Order", 'lambert-add-ons'),      
        ),
        array(
            "type" => "textfield",
            "heading" => __("Or Enter Member IDs", 'lambert-add-ons'),
            "param_name" => "ids",
            "description" => __("Enter member ids to show, separated by a comma. (ex: 99,100)", 'lambert-add-ons')
        ),
        array(
            "type" => "dropdown",
            "class"=>"",
            "heading" => __('Disable Popup', 'lambert-add-ons'),
            "param_name" => "dis_popup",
            "value" => array(   
                            __('Yes', 'lambert-add-ons') => 'yes',  
                            __('No', 'lambert-add-ons') => 'no',                                                                                
                        ),
            //"description" => __("Set this to No to hide filter buttons bar.", "lambert"), 
            'std'=> 'no'
        ),
        array(
            "type" => "textfield",
            "heading" => __("Extra class name", 'lambert-add-ons'),
            "param_name" => "el_class",
            "description" => __("If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'lambert-add-ons')
        ),
    )
));
if ( class_exists( 'WPBakeryShortCode' ) ) {
    class WPBakeryShortCode_Cth_Team extends WPBakeryShortCode {}
}

