<?php 
/* add_ons_php */
vc_map( array(
    "name" => __("Menu Background Image", 'lambert-add-ons'),
    "base" => "cth_image_menu_parallax",
    "content_element" => true,
    "icon"                     => BBT_DIR_URL . "/assets/cththemes-logo.png",
    "category"=>'Lambert Old',
    "params" => array(
        array(
            "type"      => "attach_image",
            //"holder"    => "div",
            "class"     => "",
            "heading"   => __("Background Image", 'lambert-add-ons'),
            "param_name"=> "bgimg",
            //"description" => __("Background Image, will display in mobile device", 'lambert')
        ),
        array(
            "type" => "dropdown",
            "class"=>"",
            "holder"=>'div',
            "heading" => __('Direction', 'lambert-add-ons'),
            "param_name" => "direction",
            "value" => array(   
                            __('Left to Right', 'lambert-add-ons') => 'Left-to-Right',  
                            __('Right to Left', 'lambert-add-ons') => 'Right-to-Left',  
                                                                                                          
                        ),
            //"description" => __("Set this to Yes if you want to display single item only", 'lambert'), 
        ),
        array(
            "type"      => "textfield",
            "class"     => "",
            "holder"=>'div',
            "heading"   => __("Transform In", 'lambert-add-ons'),
            "param_name"=> "in",
            "value"     => "transform: translateX(-200px);",
            "description" => __("Transform In", 'lambert-add-ons')
        ),
        array(
            "type"      => "textfield",
            "class"     => "",
            "holder"=>'div',
            "heading"   => __("Transform Out", 'lambert-add-ons'),
            "param_name"=> "out",
            "value"     => "transform: translateX(200px);",
            "description" => __("Transform Out", 'lambert-add-ons')
        ), 
         
        array(
            "type" => "textfield",
            "heading" => __("Extra class name", 'lambert-add-ons'),
            "param_name" => "el_class",
            "description" => __("If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'lambert-add-ons')
        ),
        
        
        
    )
));

if ( class_exists( 'WPBakeryShortCode' ) ) {
    class WPBakeryShortCode_Cth_Image_Menu_Parallax extends WPBakeryShortCode {     
    }
}

