<?php 
/* add_ons_php */
vc_map( array(
    "name" => __("Deal", 'lambert-add-ons'),
    "base" => "cth_deal",
    "content_element" => true,
    "category"=>'Lambert Theme',
    "icon"                     => BBT_DIR_URL . "/assets/cththemes-logo.png",
    "params" => array(
        array(
            "type"      => "textfield",
            "class"     => "",
            "holder"    => "div",
            "heading"   => __("Day", 'lambert-add-ons'),
            "param_name"=> "day",
            "value"     => "Monday",
            "description" => __("Day", 'lambert-add-ons')
        ),
        array(
            "type"      => "textfield",
            "class"     => "",
            "holder"    => "div",
            "heading"   => __("Name", 'lambert-add-ons'),
            "param_name"=> "name",
            "value"     => "( Labore et dolore )",
            "description" => __("Name", 'lambert-add-ons')
        ),
        
        array(
            "type" => "textarea",
            "heading" => __("Deal Description", 'lambert-add-ons'),
            "param_name" => "content",
            "value"=>'Oatmeal Apples',
            "description" => __("Deal Description", 'lambert-add-ons')
        ),
        array(
            "type"      => "textfield",
            "class"     => "",
            "holder"    => "div",
            "heading"   => __("Price", 'lambert-add-ons'),
            "param_name"=> "price",
            "value"     => "$34",
            "description" => __("Price", 'lambert-add-ons')
        ),
        array(
            "type"      => "textfield",
            "class"     => "",
            "holder"    => "div",
            "heading"   => __("Discount Price", 'lambert-add-ons'),
            "param_name"=> "discount",
            "value"     => "$26",
            "description" => __("Discount Price", 'lambert-add-ons')
        ),
        array(
            "type" => "textfield",
            "heading" => __("Extra class name", 'lambert-add-ons'),
            "param_name" => "el_class",
            "description" => __("If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'lambert-add-ons')
        ),
        
        
        
    )
));

if ( class_exists( 'WPBakeryShortCode' ) ) {
    class WPBakeryShortCode_Cth_Deal extends WPBakeryShortCode {     
    }
}


