<?php 
/* add_ons_php */
vc_map( array(
    "name"      => esc_html__("Single Testimonial", 'lambert-add-ons'),
    "base"      => "lambert_single_testimonial",
    "class"     => "",
    "icon"                     => BBT_DIR_URL . "/assets/cththemes-logo.png",
    "category"  => 'Lambert Theme',
    "show_settings_on_create" => true,
    "params"    => array(
        
        array(
            "type" => "textfield",
            "admin_label" => true,
            "heading" => esc_html__("Testimonial ID", 'lambert-add-ons'),
            "param_name" => "id",
            "value" => "1288",
            "description" => esc_html__("Enter testimonial id to show. Ex: 1288", 'lambert-add-ons')
        ),
        array(
            "type" => "dropdown",
            "heading" => esc_html__('Show Avatar', 'lambert-add-ons'),
            "param_name" => "show_avatar",
            "value" => array(   
                            esc_html__('No', 'lambert-add-ons') => 'no',  
                            esc_html__('Yes', 'lambert-add-ons') => 'yes',
                            
                                                                                                              
                            ),
            "description" => esc_html__("Show avatar", 'lambert-add-ons'),    
            "std" => "yes"     
        ),
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Show Title", 'lambert-add-ons'),
            "param_name" => "show_title",

            "value" => array( 
                esc_html__('No', 'lambert-add-ons') => 'no',  
                esc_html__('Yes', 'lambert-add-ons') => 'yes',   
                
                  
            ),
            "std"=>'no', 
        ),
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Show Rating", 'lambert-add-ons'),
            "param_name" => "show_rating",
        
            "value" => array( 
                esc_html__('No', 'lambert-add-ons') => 'no',  
                esc_html__('Yes', 'lambert-add-ons') => 'yes',   
                
                  
            ),
            "std"=>'yes', 
        ),

        array(
            "type" => "textfield",
            "heading" => esc_html__("Extra class name", 'lambert-add-ons'),
            "param_name" => "el_class",
            "description" => esc_html__("If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'lambert-add-ons')
        ),
        array(
            'type' => 'css_editor',
            'heading' => esc_html__( 'Css', 'lambert-add-ons' ),
            'param_name' => 'css',
            'group' => esc_html__( 'Design options', 'lambert-add-ons' ),
        ),
    )));

if ( class_exists( 'WPBakeryShortCode' ) ) {
    class WPBakeryShortCode_Lambert_Single_Testimonial extends WPBakeryShortCode {}
}

