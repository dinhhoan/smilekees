<?php 
/* add_ons_php */
vc_map( array(
    "name" => __("Parallax Background Image", 'lambert-add-ons'),
    "base" => "cth_image_parallax",
    "content_element" => true,
    "icon"                     => BBT_DIR_URL . "/assets/cththemes-logo.png",
    "category"=>'Lambert Theme',
    "params" => array(
        array(
            "type"      => "attach_image",
            "holder"    => "div",
            "class"     => "",
            "heading"   => __("Background Image", 'lambert-add-ons'),
            "param_name"=> "bgimg",
            //"description" => __("Background Image, will display in mobile device", 'lambert')
        ),
        array(
            "type"      => "textfield",
            // "class"     => "",
            "heading"   => esc_html__("Overlay Opacity", 'lambert-add-ons'),
            "param_name"=> "parallax_inner_op",
            "value"     => "0.5",
            "description" => esc_html__("Overlay Opacity value 0.0 - 1. Ex: 0.5", 'lambert-add-ons'),
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__('Background Parallax Value', 'lambert-add-ons'),
            "param_name" => "parallax_inner_val",
            "value" => "300",
            "description" => esc_html__("Pixel number. Which we are telling the browser is to move Background Image down every time we scroll down 100% of the viewport height and move Background Image up every time we scroll up 100% of the viewport height. Ex: 300 or -300 for reverse direction.", 'lambert-add-ons'),
        ) ,
         
        array(
            "type" => "textfield",
            "heading" => __("Extra class name", 'lambert-add-ons'),
            "param_name" => "el_class",
            "description" => __("If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'lambert-add-ons')
        ),
        
        
        
    )
));

if ( class_exists( 'WPBakeryShortCode' ) ) {
    class WPBakeryShortCode_Cth_Image_Parallax extends WPBakeryShortCode {     
    }
}

