<?php 
/* add_ons_php */
vc_map( array(
    "name" => __("Home Image Background", 'lambert-add-ons'),
    "base" => 'do'.'mik'."_home_image",
    "content_element" => true,
    "icon"                     => BBT_DIR_URL . "/assets/cththemes-logo.png",
    "category"=>'Lambert Theme',
    "params" => array(
        
        array(
            "type"      => "attach_image",
            "holder"    => "div",
            "class"     => "ajax-vc-img",
            "heading"   => __("Background Image", 'lambert-add-ons'),
            "param_name"=> "bgimg",
            "description" => __("Background image for mobile device", 'lambert-add-ons')
        ),
        array(
            "type"      => "textarea_raw_html",
            //"holder"    => "div",
            "class"     => "",
            // "ace_mode"=>"html",
            // "ace_style"=>"min-height:300px;border:1px solid #bbb;",
            "heading"   => __("Content", 'lambert-add-ons'),
            "param_name"=> "content",
            "description" => __("Content", 'lambert-add-ons')
        ),  
        array(
            "type" => "textfield",
            "heading" => esc_html__('Background Parallax Value', 'lambert-add-ons'),
            "param_name" => "parallax_val",
            "value" => "300",
            "description" => esc_html__("Pixel number. Which we are telling the browser is to move Background Image down every time we scroll down 100% of the viewport height and move Background Image up every time we scroll up 100% of the viewport height. Ex: 300 or -300 for reverse direction.", 'lambert-add-ons'),
        ) ,
        array(
            "type" => "textfield",
            "heading" => __("Extra class name", 'lambert-add-ons'),
            "param_name" => "el_class",
            "description" => __("If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'lambert-add-ons')
        ),
        
        
        
    ),
    // "js_view" => 'LambertImagesView',
    // 'admin_enqueue_js' => get_template_directory_uri() . "/vc_extend/lambert-elements.js",

));

if ( class_exists( 'WPBakeryShortCode' ) ) {
    class WPBakeryShortCode_Lambert_Home_Image extends WPBakeryShortCode {     
    }
}

