<?php 
/* add_ons_php */
vc_map( array(
    "name" => __("CTH Reservation Form", 'lambert-add-ons'),
    //"description" => __("Import reservation",'lambert'),
    "category"=>'Lambert Theme',
    "base" => "cth_reservation_form",
    "content_element" => true,
    "show_settings_on_create" => false,
    "icon"                     => BBT_DIR_URL . "/assets/cththemes-logo.png",
    
    "params" => array(
        
    )
));

if ( class_exists( 'WPBakeryShortCode' ) ) {
    class WPBakeryShortCode_Cth_Reservation_Form extends WPBakeryShortCode {     
    }
}


