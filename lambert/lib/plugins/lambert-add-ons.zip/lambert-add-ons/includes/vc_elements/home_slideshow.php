<?php 
/* add_ons_php */
vc_map( array(
    "name" => __("Home Slideshow", 'lambert-add-ons'),
    "base" => "cth_home_slideshow",
    "content_element" => true,
    "icon"                     => BBT_DIR_URL . "/assets/cththemes-logo.png",
    "category"=>'Lambert Theme',
    "params" => array(
        
        array(
            "type"      => "attach_images",
            "holder"    => "div",
            "class"     => "ajax-vc-img",
            "heading"   => __("Slideshow Images", 'lambert-add-ons'),
            "param_name"=> "bgimgs",
            "description" => __("Background Slideshow images", 'lambert-add-ons')
        ),
        array(
            "type"      => "textarea_raw_html",
            //"holder"    => "div",
            "class"     => "",
            // "ace_mode"=>"html",
            // "ace_style"=>"min-height:300px;border:1px solid #bbb;",
            "heading"   => __("Content", 'lambert-add-ons'),
            "param_name"=> "content",
            "description" => __("Content", 'lambert-add-ons')
        ),  
         
        array(
            "type" => "textfield",
            "heading" => __("Extra class name", 'lambert-add-ons'),
            "param_name" => "el_class",
            "description" => __("If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'lambert-add-ons')
        ),
        
        
        
    ),
    // "js_view" => 'LambertImagesView',
    // 'admin_enqueue_js' => get_template_directory_uri() . "/vc_extend/lambert-elements.js",
));

if ( class_exists( 'WPBakeryShortCode' ) ) {
    class WPBakeryShortCode_Cth_Home_Slideshow extends WPBakeryShortCode {     
    }
}


