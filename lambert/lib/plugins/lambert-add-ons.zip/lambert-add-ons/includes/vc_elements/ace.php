<?php
/* add_ons_php */
vc_map(array(
    "name"     => __("ACE Raw HTML", 'lambert-add-ons'),
    "base"     => "cthace",
    "class"    => "",
    "icon"     => BBT_DIR_URL . "/assets/cththemes-logo.png",
    "category" => 'Lambert Old',
    "params"   => array(
        array(
            "type"       => "textarea_raw_html",
            "heading"    => __('HTML Code', 'lambert-add-ons'),
            "param_name" => "content",
            // "ace_mode"=>"html",
            // "ace_style"=>"min-height:500px;border:1px solid #bbb;",
            "value"      => "",
        ),

    )));

if (class_exists('WPBakeryShortCode')) {
    class WPBakeryShortCode_Cthace extends WPBakeryShortCode
    {}
}
