<?php 
/* add_ons_php */
vc_map( array(
    "name" => __("Menu", 'lambert-add-ons'),
    "base" => "cth_menu",
    "content_element" => true,
    "category"=>'Lambert Old',
    "icon"                     => BBT_DIR_URL . "/assets/cththemes-logo.png",
    
    "params" => array(
        array(
            "type"      => "textfield",
            "class"     => "",
            "holder"    => "div",
            "heading"   => __("Title", 'lambert-add-ons'),
            "param_name"=> "title",
            "value"     => "Steak Filet",
            "description" => __("Title", 'lambert-add-ons')
        ),
        array(
            "type"      => "textfield",
            "class"     => "",
            "holder"    => "div",
            "heading"   => __("Price", 'lambert-add-ons'),
            "param_name"=> "price",
            "value"     => "$130",
            "description" => __("Price", 'lambert-add-ons')
        ),
        array(
            "type"      => "textfield",
            "class"     => "",
            "holder"    => "div",
            "heading"   => __("Sale Info", 'lambert-add-ons'),
            "param_name"=> "sale",
            "value"     => "",
            "description" => __("Sale Info. (ex: `Sale - 20%` or `Chief Selection`)", 'lambert-add-ons')
        ),
        
        array(
            "type"      => "attach_image",
            //"holder"    => "div",
            "class"     => "",
            "heading"   => __("Description Image", 'lambert-add-ons'),
            "param_name"=> "desimg",
            "description" => __("Description Image", 'lambert-add-ons')
        ),
        
        
         
        
        array(
            "type" => "textarea",
            "heading" => __("Description", 'lambert-add-ons'),
            "holder"=>'div',
            "param_name" => "content",
            "value"=>"<p>Sed quia non numquam eius modi tempora</p>",
            "description" => __("Description", 'lambert-add-ons')
        ),
        array(
            "type" => "textfield",
            "heading" => __("Extra class name", 'lambert-add-ons'),
            "param_name" => "el_class",
            "description" => __("If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'lambert-add-ons')
        ),
        
        
        
    )
));

if ( class_exists( 'WPBakeryShortCode' ) ) {
    class WPBakeryShortCode_Cth_Menu extends WPBakeryShortCode {     
    }
}


