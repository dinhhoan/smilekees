<?php 
/* add_ons_php */
vc_map( array(
   "name"      => __("Team Member", 'lambert-add-ons'),
   "description" => __("Team member",'lambert-add-ons'),
   "base"      => "cth_member",
   "class"     => "",
   "icon"                     => BBT_DIR_URL . "/assets/cththemes-logo.png",
   "category"  => 'Lambert Old',
   "params"    => array(
        array(
            "type" => "textfield",
            "heading" => __("Name", 'lambert-add-ons'),
            "holder"    => "div",
            "value"=>'Andy Moore',
            "param_name" => "name",
            "description" => __("Member name", 'lambert-add-ons')
        ),
        array(
            "type" => "textfield",
            "heading" => __("Job", 'lambert-add-ons'),
            //"holder"    => "div",
            "param_name" => "job",
            "value"=>'Master chef in Brooklin',
            "description" => __("Member Job", 'lambert-add-ons')
        ),
        array(
            "type"      => "attach_image",
            "class"     => "",
            "heading"   => __("Photo", 'lambert-add-ons'),
            "param_name"=> "photo",
            "value"     => "",
            "description" => __("Upload avatar photo of the member", 'lambert-add-ons')
        ),
        array(
            "type"      => "textarea",
            "class"     => "",
            "heading"   => __("Member Introduction", 'lambert-add-ons'),
            "param_name"=> "content",
            "value"     => '<p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat. Xillum dolore eu fugiat nulla pariatur. olore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
<h5>Find on : </h5>
<ul class="team-social">
<li><a href="#"  target="_blank" class="elem"><i class="fa fa-facebook"></i></a></li>
<li><a href="#"  target="_blank" class="elem"><i class="fa fa-twitter"></i></a></li>
<li><a href="#"  target="_blank" class="elem"><i class="fa fa-dribbble"></i></a></li>
<li><a href="#"  target="_blank" class="elem"><i class="fa fa-pinterest-square"></i></a></li>
</ul>',
            "description" => __("Introduction", 'lambert-add-ons')
        ),
        array(
            "type" => "dropdown",
            "class"=>"",
            "heading" => __('Disable Popup', 'lambert-add-ons'),
            "param_name" => "dis_popup",
            "value" => array(   
                            __('Yes', 'lambert-add-ons') => 'yes',  
                            __('No', 'lambert-add-ons') => 'no',                                                                                
                        ),
            //"description" => __("Set this to No to hide filter buttons bar.", "lambert"), 
            'std'=> 'no'
        ),
        array(
            "type" => "textfield",
            "heading" => __("Extra class name", 'lambert-add-ons'),
            "param_name" => "el_class",
            "description" => __("If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'lambert-add-ons')
        ),
    )
));
if ( class_exists( 'WPBakeryShortCode' ) ) {
    class WPBakeryShortCode_Cth_Member extends WPBakeryShortCode {}
}

