<?php 
/* add_ons_php */
require_once BBT_ABSPATH . 'older_2_dot_4/fields.php';
$options = array( 
        array(
            "name" => "Rerservation Form Settings",
            "type" => "sub-section-3",
            //"category" => "header-styles",
        ),
        array(
        "name" => "Reservation Form Fields",
        "desc" => "The text string will be used in reservation content. The <code>[name]</code> text will be replaced by data in <code>name</code> field from your reservation form, and so on.<br><br><a href=\"".BBT_DIR_URL.'assets/img/res_form_fields.png'."\" target=\"_blank\"><img src=\"".BBT_DIR_URL.'assets/img/res_form_fields.png'."\" style=\"max-width:100%;height:auto;\"></a>",
        "id" => "_reservation_form_field",
        "type" => "ace_editor",
        "cols"=> "100", //textarea only
        "rows"=> "15", //textarea only
        "parent" => "cth_reservation_options-group",
        "std" => '<div class="row">
    <div class="col-md-6">
        <h3>Book a table</h3>
        <!--date-->
        <input name="resdate" type="text" class="myInput ionDateSelector" data-lang="en" data-years="2017-2030" data-format="YYYY-MM-DD" data-sundayfirst="false"  required aria-required="true" placeholder="Reservation Date - YYYY-MM-DD">
        <!--time--> 
        <select name="restime" id="restime" class="form-control">
            <option value="5:00am">5:00 am</option>
            <option value="5:30am">5:30 am</option>
            <option value="6:00am">6:00 am</option>
            <option value="6:30am">6:30 am</option>
            <option selected="selected" value="7:00am">7:00 am</option>
            <option value="7:30am">7:30 am</option>
            <option value="8:00am">8:00 am</option>
            <option value="8:30am">8:30 am</option>
            <option value="9:00am">9:00 am</option>
            <option value="9:30am">9:30 am</option>
            <option value="10:00am">10:00 am</option>
            <option value="10:30am">10:30 am</option>
            <option value="11:00am">11:00 am</option>
            <option value="11:30am">11:30 am</option>
            <option value="12:00pm">12:00 pm</option>
            <option value="12:30pm">12:30 pm</option>
            <option value="1:00pm">1:00 pm</option>
            <option value="1:30pm">1:30 pm</option>
            <option value="2:00pm">2:00 pm</option>
            <option value="2:30pm">2:30 pm</option>
            <option value="3:00pm">3:00 pm</option>
            <option value="3:30pm">3:30 pm</option>
            <option value="4:00pm">4:00 pm</option>
            <option value="4:30pm">4:30 pm</option>
            <option value="5:00pm">5:00 pm</option>
            <option value="5:30pm">5:30 pm</option>
            <option value="6:00pm">6:00 pm</option>
            <option value="6:30pm">6:30 pm</option>
            <option value="7:00pm">7:00 pm</option>
            <option value="7:30pm">7:30 pm</option>
            <option value="8:00pm">8:00 pm</option>
            <option value="8:30pm">8:30 pm</option>
            <option value="9:00pm">9:00 pm</option>
            <option value="9:30pm">9:30 pm</option>
            <option value="10:00pm">10:00 pm</option>
            <option value="10:30pm">10:30 pm</option>
            <option value="11:00pm">11:00 pm</option>
            <option value="11:30pm">11:30 pm</option>
        </select>
        <!--restaurant-->                                      
        <select name="resrest" class="form-control" id="resrest">
            <option selected="selected" value="Lambert - New York City">Lambert  - New York City</option>
            <option value="Lambert - Washington">Lambert - Washington</option>
            <option value="Lambert - Florida ">Lambert - Florida</option>
        </select>
        <!--person-->    
        <select name="numperson" id="numperson" class="form-control" >
            <option value="1">1 Person</option>
            <option selected="selected" value="2">2 People</option>
            <option value="3">3 People</option>
            <option value="4">4 People</option>
            <option value="5">5 People</option>
            <option value="6">6 People</option>
            <option value="7">7 People</option>
            <option value="8">8 People</option>
            <option value="9">9 People</option>
            <option value="10">10 People</option>
            <option value="11">11 People</option>
            <option value="12">12 People</option>
            <option value="13">13 People</option>
            <option value="14">14 People</option>
            <option value="15">15 People</option>
            <option value="16">16 People</option>
            <option value="17">17 People</option>
            <option value="18">18 People</option>
            <option value="19">19 People</option>
            <option value="20">20 People</option>
            <option value="20+">20+ People</option>
        </select>
    </div>
    <div class="col-md-6">
        <h3>Contact Details</h3>
        <!--name--> 
        <input name="name" type="text" id="name"   required aria-required="true" placeholder="Your Name">
        <!--mail--> 
        <input name="email" type="text" id="email"  required aria-required="true" placeholder="Your Email">
        <!--phone--> 
        <input name="phone" type="text" id="phone"  required aria-required="true" placeholder="Your Phone">         
        <!--message-->    
        <textarea name="comments" rows="5"  id="comments"  required aria-required="true" placeholder="Your Message"></textarea>
    </div>
</div>'
    ),

    array("name" => "Show Captcha",
            "desc" => "",
            "id" => "_reservation_show_captcha",
            "type" => "select",
            //"options" => array("yes" => __('Yes','lambert-add-ons'), "no" => __('No','lambert-add-ons')),
            "options" => array("yes" => "Yes", "no" => "No"),
            "parent" => "reservation_form",
            //"std" => 'yes'
    ),

    array(
        "name" => "Reservation Title Field",
        "desc" => "Enter your form field name that will be used for Reservation'title.",
        "id" => "_reservation_title_field",
        "type" => "text",
        "parent" => "reservation_form",
        "std" => "name"
    ),
    array(
        "name" => "Reservation content format string",
        "desc" => "The text string will be used in reservation content. The <code>[name]</code> text will be replaced by data in <code>name</code> field from your reservation form, and so on.<br><br><a href=\"".BBT_DIR_URL.'assets/img/res_content_format.png'."\" target=\"_blank\"><img src=\"".BBT_DIR_URL.'assets/img/res_content_format.png'."\" style=\"max-width:100%;height:auto;\"></a>",
        "id" => "_reservation_content_template",
        "type" => "editor",
        "cols"=> "100", //textarea only
        "rows"=> "15", //textarea only
        "parent" => "cth_reservation_options-group",
        "std" => "<h4 align=\"center\">Reservation Info</h4>
<br />
<p align=\"left\">Name: <strong>[name]</strong></p>
<p align=\"left\">Phone: <strong>[phone]</strong></p>
<p align=\"left\">E-mail: <strong>[email]</strong></p>
<p align=\"left\">Resturant: <strong>[resrest]</strong></p>
<p align=\"left\">Reservation Date: <strong>[resdate]</strong></p>
<p align=\"left\">Reservation Time: <strong>[restime]</strong></p>
<p align=\"left\">Persons: <strong>[numperson]</strong></p>
<p align=\"left\"><strong>Additional Message</strong></p><br />
[comments]"
    ),
    array(
        "name" => "Email Settings",
        "type" => "sub-section-3",
        //"category" => "header-styles",
    ),
    array(
        "name" => "Sender Name",
        "desc" => "The name displayed in email header",
        "id" => "_reservation_email_sender",
        "type" => "text",
        "parent" => "email_setup",
        "std" => "Lambert",
        "style"=>"width:50%;"
    ),
    array(
        "name" => "Sender Email",
        "desc" => "Sender Email",
        "id" => "_reservation_email_sender_email",
        "type" => "text",
        "parent" => "email_setup",
        "std" => "contact.cththemes@gmail.com",
        "style"=>"width:50%;"
    ),
    array(
        "name" => "To",
        "desc" => "Enter your form field name that confirming email will send to.",
        "id" => "_reservation_confirming_email_to",
        "type" => "text",
        "parent" => "email_setup",
        "std" => "email"
    ),
    array("name" => "Send comfirm email after book",
            "desc" => "",
            "id" => "_reservation_confirm_after_booked",
            "type" => "radio",
            //"options" => array("yes" => __('Yes','lambert-add-ons'), "no" => __('No','lambert-add-ons')),
            "options" => array("yes" => "Yes", "no" => "No"),
            "parent" => "email_setup",
            "std" => 'yes'
    ),
    array("name" => "Use HTML content type",
            "desc" => "Use HTML content type",
            "id" => "_reservation_email_content_type",
            "type" => "radio",
            //"options" => array("yes" => __('Yes','lambert-add-ons'), "no" => __('No','lambert-add-ons')),
            "options" => array("yes" => "Yes", "no" => "No"),
            "parent" => "email_setup",
            "std" => 'yes'
    ),
    

    array(
        "name" => "Rerservation Confirming Settings",
        "type" => "sub-section-3",
        //"category" => "header-styles",
    ),
    array("name" => "Send Confirming Email",
            "desc" => "Set this to <code>Yes</code> if you want send confirming email when edit the reservation post status from <code>Booked</code> to <code>Confirming</code>.",
            "id" => "_reservation_confirming_email",
            "type" => "radio",
            //"options" => array("yes" => __('Yes','lambert-add-ons'), "no" => __('No','lambert-add-ons')),
            "options" => array("yes" => "Yes", "no" => "No"),
            "parent" => "comfriming_email_setup",
            "std" => 'yes'
    ),
    
    array(
        "name" => "Email Subject",
        "desc" => "Comfirming Email Subject.",
        "id" => "_reservation_confirming_email_subject",
        "type" => "text",
        "parent" => "comfriming_email_setup",
        "std" => "Reservation Confirming",
        "style"=>"width:100%;"
    ),
    array(
        "name" => "Confirm Email Template",
        "desc" => "The text string will be used in comfirm email. The <code>[name]</code> text will be replaced by data in <code>name</code> field from your reservation form, and so on.",
        "id" => "_reservation_confirming_email_template",
        "type" => "editor",
        "cols"=> "100", //textarea only
        "rows"=> "15", //textarea only
        "parent" => "complete_email_setup",
        "std" => '<p align="left">Hi [name],</p>
<p align="left">You received this email because you have booked a table at [resrest] - Restaurant. Bellow is the detail:</p>
<p align="left"><em>Name: [name]</em></p>
<p align="left"><em>Phone: [phone]</em></p>
<p align="left"><em>E-mail: [email]</em></p>
<p align="left"><em>Resturant: [resrest]</em></p>
<p align="left"><em>Reservation Date: [resdate]</em></p>
<p align="left"><em>Reservation Time: [restime]</em></p>
<p align="left"><em>Persons: [numperson]</em></p>
<p align="left"><em><strong>Additional Message</strong></em></p>
<p align="left"><em>[comments]</em></p>
<p align="left">To comfirm the reservation please click this link: [reservation_confirm_link]</p>
<p align="left"><strong>Sincerely,</strong></p>
<p align="left"><strong>Cththemes</strong></p>'
    ),

    array(
        "name" => "Rerservation Confirmed Settings",
        "type" => "sub-section-3",
        //"category" => "header-styles",
    ),
    array("name" => "Send Confirmed Email",
            "desc" => "Set this to <code>Yes</code> if you want send confirmed email when user click on <code>confirm link</code> send with <code>comfirming email</code> above or edit (back-end) the <code>reservation post status</code> from <code>Confirming</code> to <code>Confirmed</code>.",
            "id" => "_reservation_confirmed_email",
            "type" => "radio",
            //"options" => array("yes" => __('Yes','lambert-add-ons'), "no" => __('No','lambert-add-ons')),
            "options" => array("yes" => "Yes", "no" => "No"),
            "parent" => "comfrimed_email_setup",
            "std" => 'yes'
    ),
    
    array(
        "name" => "Email Subject",
        "desc" => "Comfirmed Email Subject.",
        "id" => "_reservation_confirmed_email_subject",
        "type" => "text",
        "parent" => "comfrimed_email_setup",
        "std" => "Reservation Confirmed",
        "style"=>"width:100%;"
    ),

    array(
        "name" => "Confirmed Email Template",
        "desc" => "The text string will be used in comfirmed email. The <code>[name]</code> text will be replaced by data in <code>name</code> field from your reservation form, and so on.",
        "id" => "_reservation_confirmed_email_template",
        "type" => "editor",
        "cols"=> "100", //textarea only
        "rows"=> "15", //textarea only
        "parent" => "complete_email_setup",
        "std" => '<p align="left">Hi [name],</p>
<p align="left">Thank you for confirmed your reservation at our [resrest] - Restaurant.</p>
<p align="left"><strong>Cththemes</strong></p>'
    ),

    array(
        "name" => "Rerservation Complete Settings",
        "type" => "sub-section-3",
        //"category" => "header-styles",
    ),
    array("name" => "Send Complete Email",
            "desc" => "Set this to <code>Yes</code> if you want send complete email when you edit (back-end) the <code>reservation post status</code> from <code>Comfirmed</code> to <code>Complete</code>.",
            "id" => "_reservation_complete_email",
            "type" => "radio",
            //"options" => array("yes" => __('Yes','lambert-add-ons'), "no" => __('No','lambert-add-ons')),
            "options" => array("yes" => "Yes", "no" => "No"),
            "parent" => "complete_email_setup",
            "std" => 'yes'
    ),
    
    array(
        "name" => "Email Subject",
        "desc" => "Complete Email Subject.",
        "id" => "_reservation_complete_email_subject",
        "type" => "text",
        "parent" => "complete_email_setup",
        "std" => "Reservation Complete",
        "style"=>"width:100%;"
    ),

    array(
        "name" => "Complete Email Template",
        "desc" => "The text string will be used in complete email. The <code>[name]</code> text will be replaced by data in <code>name</code> field from your reservation form, and so on.",
        "id" => "_reservation_complete_email_template",
        "type" => "editor",
        "cols"=> "100", //textarea only
        "rows"=> "15", //textarea only
        "parent" => "complete_email_setup",
        "std" => '<p align="left">Hi [name],</p>
<p align="left">Thank you for your arrival. See you again.</p>
<p align="left"><strong>Cththemes</strong></p>'
    ),

    array(
        "name" => "Confirmed Message",
        "desc" => "The text string will be used in confirmed page, after confirmed status.",
        "id" => "_reservation_confirmed_page_message",
        "type" => "editor",
        "cols"=> "100", //textarea only
        "rows"=> "5", //textarea only
        "parent" => "confirmed_page_message",
        "std" => ''
    ),
 );

?>
<div class="wrap">
<h2><?php _e('Lambert Reservation','lambert-add-ons');?></h2>
<form method="post" action="options.php">
    <?php settings_fields( 'cth_reservation' ); ?>
    <?php //do_settings_sections( 'my-cool-plugin-settings-group' ); ?>
        <?php
            cth_reservation_create_form($options);
        ?>
    <?php submit_button(); ?>
</form>
</div><!-- end wrap -->