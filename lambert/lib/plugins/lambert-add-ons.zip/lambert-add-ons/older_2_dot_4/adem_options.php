<?php 
/* add_ons_php */
require_once BBT_ABSPATH . 'older_2_dot_4/fields.php';


$options = array( 

    

    array(
        "name" => "New Reservation Admin Email Settings",
        "type" => "sub-section-3",
        //"category" => "header-styles",
    ),
    // array("name" => "Send Confirming Email",
    //         "desc" => "Set this to <code>Yes</code> if you want send confirming email when edit the reservation post status from <code>Booked</code> to <code>Confirming</code>.",
    //         "id" => "_reservation_confirming_email",
    //         "type" => "radio",
    //         //"options" => array("yes" => __('Yes','cth-reservation'), "no" => __('No','cth-reservation')),
    //         "options" => array("yes" => "Yes", "no" => "No"),
    //         "parent" => "comfriming_email_setup",
    //         "std" => 'yes'
    // ),
    array(
        "name" => "Admin Email",
        "desc" => "The email that will receive a message when new reservation was booked.",
        "id" => "_emails_reservation_admin_email",
        "type" => "text",
        "parent" => "admin_email_setup",
        "std" => "contact.cththemes@gmail.com",
        "style"=>"width:50%;"
    ),
    
    array(
        "name" => "Admin Email Subject",
        "desc" => "Admin Email Subject.",
        "id" => "_emails_reservation_admin_subject",
        "type" => "text",
        "parent" => "admin_email_setup",
        "std" => "New Reservation Booked",
        "style"=>"width:100%;"
    ),
    array(
        "name" => "Admin Email Template",
        "desc" => "The text string will be used in comfirm email. The <code>[name]</code> text will be replaced by data in <code>name</code> field from your reservation form, and so on.",
        "id" => "_emails_reservation_admin_template",
        "type" => "editor",
        "cols"=> "100", //textarea only
        "rows"=> "15", //textarea only
        "parent" => "admin_email_setup",
        "std" => '
<p align="left">New reservation was booked at [resrest] - Restaurant. Bellow is the detail:</p>
<p align="left"><em>Name: [name]</em></p>
<p align="left"><em>Phone: [phone]</em></p>
<p align="left"><em>E-mail: [email]</em></p>
<p align="left"><em>Resturant: [resrest]</em></p>
<p align="left"><em>Reservation Date: [resdate]</em></p>
<p align="left"><em>Reservation Time: [restime]</em></p>
<p align="left"><em>Persons: [numperson]</em></p>
<p align="left"><em><strong>Additional Message</strong></em></p>
<p align="left"><em>[comments]</em></p>'
    ),

    array(
        "name" => "Email Subject",
        "desc" => "Comfirming Email Subject.",
        "id" => "_emails_reservation_confirming_admin_subject",
        "type" => "text",
        "parent" => "admin_email_setup",
        "std" => "Reservation Confirming",
        "style"=>"width:100%;"
    ),
    array(
        "name" => "Confirm Email Template",
        "desc" => "The text string will be used in comfirm email. The <code>[name]</code> text will be replaced by data in <code>name</code> field from your reservation form, and so on.",
        "id" => "_emails_reservation_confirming_admin_template",
        "type" => "editor",
        "cols"=> "100", //textarea only
        "rows"=> "15", //textarea only
        "parent" => "admin_email_setup",
        "std" => '<p align="left">Hi [name],</p>
<p align="left">You received this email because you have booked a table at [resrest] - Restaurant. Bellow is the detail:</p>
<p align="left"><em>Name: [name]</em></p>
<p align="left"><em>Phone: [phone]</em></p>
<p align="left"><em>E-mail: [email]</em></p>
<p align="left"><em>Resturant: [resrest]</em></p>
<p align="left"><em>Reservation Date: [resdate]</em></p>
<p align="left"><em>Reservation Time: [restime]</em></p>
<p align="left"><em>Persons: [numperson]</em></p>
<p align="left"><em><strong>Additional Message</strong></em></p>
<p align="left"><em>[comments]</em></p>
<p align="left">To comfirm the reservation please click this link: [reservation_confirm_link]</p>
<p align="left"><strong>Sincerely,</strong></p>
<p align="left"><strong>Cththemes</strong></p>'
    ),


//     array(
//         "name" => "Rerservation Confirmed Settings",
//         "type" => "sub-section-3",
//         //"category" => "header-styles",
//     ),
//     array("name" => "Send Confirmed Email",
//             "desc" => "Set this to <code>Yes</code> if you want send confirmed email when user click on <code>confirm link</code> send with <code>comfirming email</code> above or edit (back-end) the <code>reservation post status</code> from <code>Confirming</code> to <code>Confirmed</code>.",
//             "id" => "_reservation_confirmed_email",
//             "type" => "radio",
//             //"options" => array("yes" => __('Yes','cth-reservation'), "no" => __('No','cth-reservation')),
//             "options" => array("yes" => "Yes", "no" => "No"),
//             "parent" => "admin_email_setup",
//             "std" => 'yes'
//     ),
    
    array(
        "name" => "Email Subject",
        "desc" => "Comfirmed Email Subject.",
        "id" => "_emails_reservation_confirmed_admin_subject",
        "type" => "text",
        "parent" => "admin_email_setup",
        "std" => "Reservation Confirmed",
        "style"=>"width:100%;"
    ),

    array(
        "name" => "Confirmed Email Template",
        "desc" => "The text string will be used in comfirmed email. The <code>[name]</code> text will be replaced by data in <code>name</code> field from your reservation form, and so on.",
        "id" => "_emails_reservation_confirmed_admin_template",
        "type" => "editor",
        "cols"=> "100", //textarea only
        "rows"=> "15", //textarea only
        "parent" => "admin_email_setup",
        "std" => '<p align="left">Hi [name],</p>
<p align="left">Thank you for confirmed your reservation at our [resrest] - Restaurant.</p>
<p align="left"><strong>Cththemes</strong></p>'
    ),

//     array(
//         "name" => "Rerservation Complete Settings",
//         "type" => "sub-section-3",
//         //"category" => "header-styles",
//     ),
//     array("name" => "Send Complete Email",
//             "desc" => "Set this to <code>Yes</code> if you want send complete email when you edit (back-end) the <code>reservation post status</code> from <code>Comfirmed</code> to <code>Complete</code>.",
//             "id" => "_reservation_complete_email",
//             "type" => "radio",
//             //"options" => array("yes" => __('Yes','cth-reservation'), "no" => __('No','cth-reservation')),
//             "options" => array("yes" => "Yes", "no" => "No"),
//             "parent" => "admin_email_setup",
//             "std" => 'yes'
//     ),
    
    array(
        "name" => "Email Subject",
        "desc" => "Complete Email Subject.",
        "id" => "_emails_reservation_complete_admin_subject",
        "type" => "text",
        "parent" => "admin_email_setup",
        "std" => "Reservation Complete",
        "style"=>"width:100%;"
    ),

    array(
        "name" => "Complete Email Template",
        "desc" => "The text string will be used in complete email. The <code>[name]</code> text will be replaced by data in <code>name</code> field from your reservation form, and so on.",
        "id" => "_emails_reservation_complete_admin_template",
        "type" => "editor",
        "cols"=> "100", //textarea only
        "rows"=> "15", //textarea only
        "parent" => "admin_email_setup",
        "std" => '<p align="left">Hi [name],</p>
<p align="left">Thank you for your arrival. See you again.</p>
<p align="left"><strong>Cththemes</strong></p>'
    ),

//     array(
//         "name" => "Confirmed Message",
//         "desc" => "The text string will be used in confirmed page, after confirmed status.",
//         "id" => "_reservation_confirmed_page_message",
//         "type" => "editor",
//         "cols"=> "100", //textarea only
//         "rows"=> "5", //textarea only
//         "parent" => "admin_email_setup",
//         "std" => ''
//     ),
 );
?>
<div class="wrap">
<h2><?php _e('Lambert Reservation Admin Emails','lambert-add-ons');?></h2>
<form method="post" action="options.php">
    <?php settings_fields( 'cth_reservation_emails' ); ?>
    <?php //do_settings_sections( 'my-cool-plugin-settings-group' ); ?>
        <?php
            cth_reservation_create_form($options);
        ?>
    <?php submit_button(); ?>
</form>
</div><!-- end wrap -->