<?php
/**
 * @var $this WPBakeryShortCode_Lambert_Home_Image
 */
$el_class = $bgimg = $opacity = $autoplay = $parallax_val = '';
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

if ($parallax_val == '') {
    $parallax_val = 0;
}

?>
<div class="content full-height hero-content <?php echo esc_attr($el_class );?>">
    <div class="slideshow-container">
        <!-- slideshow -->	
        <div class="media-container" data-top-bottom="transform: translateY(<?php echo esc_attr($parallax_val);?>px);" data-bottom-top="transform: translateY(<?php echo 0-$parallax_val;?>px);">
            <div class="bg" 
            <?php if(!empty($bgimg)) : ?>
				style="background-image:url(<?php echo wp_get_attachment_url($bgimg );?>);"
			<?php endif;?>></div>
        </div>
        <?php echo wp_kses_post(rawurldecode(base64_decode(strip_tags($content))) );?>
    </div>
</div>