<?php
/**
 * Shortcode attributes
 * @var $atts
 * @var $el_class
 * @var $bgimg
 * @var $direction
 * @var $in
 * @var $out
 * Shortcode class
 * @var $this WPBakeryShortCode_Cth_Image_Menu_Parallax
 */
$el_class = $bgimg = $in = $out = $direction = '';
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

if($direction === 'Left-to-Right'){
	$el_class .= ' lbd';
}else{
	$el_class .= ' rbd';
}
?>
<div class="menu-bg <?php echo esc_attr($el_class );?>" 
<?php if(!empty($bgimg)) : ?>
  style="background-image:url(<?php echo wp_get_attachment_url($bgimg );?>);"
<?php endif;?>
<?php if(!empty($in)) : ?>
	data-bottom-top="<?php echo esc_attr($in );?>"
<?php endif;?>
<?php if(!empty($out)) : ?>
	data-top-bottom="<?php echo esc_attr($out );?>"
<?php endif;?>
></div>