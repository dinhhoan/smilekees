<?php
/**
 * @var $this WPBakeryShortCode_Lambert_Home_Swiper
 */
$el_class = $el_id = $mousewheel = $autoplay = $loop = $direction = $speed = '';
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );
?>
<div class="swiper-container <?php echo esc_attr($el_class );?>" id="horizontal-slider" 
 data-mws="<?php echo esc_attr($speed );?>"  data-mwd="<?php echo esc_attr($direction );?>"  
<?php 
if(!empty($autoplay)){ ?>
	 data-mwa="<?php echo esc_attr($autoplay );?>" 
<?php
}
?>
<?php 
if($mousewheel == 'true'){ ?>
	 data-mwc="1" 
<?php 
}
?>
<?php 
if($loop == 'true'){ ?>
	 data-mwl="1" 
<?php 
}
?>
>
    <div class="swiper-wrapper">
        <?php echo wpb_js_remove_wpautop($content);?>

	</div>
    <div class="swiper-nav-holder hor">
        <a class="swiper-nav arrow-left transition" href="#"><i class="fa fa-long-arrow-left"></i></a>
        <a class="swiper-nav  arrow-right transition" href="#"><i class="fa fa-long-arrow-right"></i></a>
    </div>
</div>
<div class="pagination"></div>