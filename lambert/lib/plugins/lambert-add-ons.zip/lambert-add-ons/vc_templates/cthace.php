<?php
/**
 * @var $this WPBakeryShortCode_Cthace
 */
$el_class = '';
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

?>
<?php echo rawurldecode( base64_decode( strip_tags( $content ) ) );?>