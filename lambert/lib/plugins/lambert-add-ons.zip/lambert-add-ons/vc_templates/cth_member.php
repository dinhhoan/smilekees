<?php
/**
 * Shortcode attributes
 * @var $atts
 * @var $el_class
 * @var $photo
 * @var $name
 * @var $job
 * Shortcode class
 * @var $this WPBakeryShortCode_Cth_Member
 */
$el_class = $photo = $name = $job = $dis_popup = '';
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );
?>
<div class="team-item two <?php echo esc_attr($el_class );?>">
<?php if($dis_popup == 'yes') :?>
    <a href="javascript:void(0)">
    <!-- <span class="team-details"><?php _e('More info','lambert-add-ons');?></span> -->
<?php else :?>
    <a href="team/mem1.html" class="popup-with-move-anim">
    <span class="team-details"><?php _e('More info','lambert-add-ons');?></span>
<?php endif;?>
    
    <?php 
    if(!empty($photo)) { 
        echo wp_get_attachment_image( $photo, 'full', false, array('class'=>'respimg')); 
    } ?>
    <?php if(!empty($name)):?>
        <span class="chefname"><?php echo esc_attr($name ); ?></span>
    <?php endif;?>
    <?php if(!empty($job)):?>
        <span class="chefinfo"><?php echo $job; ?></span>
    <?php endif;?>
    </a>
    <br>
    <?php echo wpb_js_remove_wpautop($content,true) ;?>
</div>