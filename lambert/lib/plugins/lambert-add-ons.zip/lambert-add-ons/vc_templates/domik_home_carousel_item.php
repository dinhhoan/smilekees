<?php
/**
 * Shortcode attributes
 * @var $atts
 * @var $el_class
 * @var $slideimg
 * @var $opacity
 * Shortcode class
 * @var $this WPBakeryShortCode_Testimonials_Slider_Item
 */
$el_class = $opacity = $slideimg = '';
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );
?>
<div class="item full-height<?php echo esc_attr($el_class );?>">
    <div class="carousel-item">
        <div class="overlay" style="opacity:<?php echo esc_attr($opacity );?>;"></div>
        <div class="bg" 
<?php if(!empty($slideimg)) : ?>
	style="background-image:url(<?php echo wp_get_attachment_url($slideimg );?>)"
<?php endif;?>
></div>
        <div class="carousel-link-holder">
            <?php echo wp_kses_post(rawurldecode(base64_decode(strip_tags($content))) );?>
        </div>
    </div>
</div>