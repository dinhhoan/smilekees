<?php
/**
 * @var $this WPBakeryShortCode_Testimonials_Slider_Item
 */
$el_class = $slideimg = $opacity = '';
extract( shortcode_atts( array(
	'el_class' => '',
	'slideimg'=>'',
	'opacity'=>'0.2',
), $atts ) );
?>
<div class="swiper-slide <?php echo esc_attr($el_class );?>">
    <div class="bg" style="background-image:url(<?php echo wp_get_attachment_url($slideimg );?>);"></div>
    <div class="overlay" style="opacity:<?php echo esc_attr($opacity );?>;"></div>
    <div class="slide-title-holder">
        <?php echo wp_kses_post(rawurldecode(base64_decode(strip_tags($content))) );?>
    </div>
</div>