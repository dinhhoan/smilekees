<?php
/**
 * Shortcode attributes
 * @var $atts
 * Shortcode class
 * @var $this WPBakeryShortCode_Cth_Reservation_Form
 */
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

echo do_shortcode('[cth_reservation_form]');