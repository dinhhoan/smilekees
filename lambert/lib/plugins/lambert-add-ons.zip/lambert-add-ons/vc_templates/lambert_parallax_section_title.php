<?php

$el_class = $css = $title_text = $subtitle_text = $show_decor = '';
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$css_classes = array(
    'parallax-section-title',
    $el_class,
    vc_shortcode_custom_css_class( $css ),
);
$css_class = preg_replace( '/\s+/', ' ', implode( ' ', array_filter( $css_classes ) ) );

?>
<div class="parallax-section-title">
	<?php if($title_text!=''):?>
    <h2><?php echo esc_html($title_text);?></h2>
    <?php endif;?>
    <?php if($subtitle_text != ''):?>
    <h3><?php echo esc_html($subtitle_text);?></h3>
    <?php endif;?>
    <?php if($show_decor == 'yes') : ?>
    <div class="bold-separator"><span></span></div>
    <?php endif;?>
    <?php echo wpb_js_remove_wpautop($content,true);?>
</div>
<div class="clearfix"></div>
