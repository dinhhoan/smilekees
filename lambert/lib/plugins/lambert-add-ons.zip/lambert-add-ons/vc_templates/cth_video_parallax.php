<?php
/**
 * Shortcode attributes
 * @var $atts
 * @var $el_class
 * @var $bgimg
 * @var $video
 * Shortcode class
 * @var $this WPBakeryShortCode_Cth_Video_Parallax
 */
$el_class = $video = $videoogg = $bgimg = $parallax_inner_op = $parallax_inner_val = '';
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

if ($parallax_inner_val == '') {
    $parallax_inner_val = 0;
}
?>
<div class="media-container video-parallax <?php echo esc_attr($el_class );?>"  data-top-bottom="transform: translateY(<?php echo esc_attr($parallax_inner_val);?>px);" data-bottom-top="transform: translateY(<?php echo 0-$parallax_inner_val;?>px);">
   	<div class="bg mob-bg" 
   	<?php if(!empty($bgimg)) : ?>
		style="background-image:url(<?php echo wp_get_attachment_url($bgimg );?>);"
	<?php endif;?>></div>
    <div class="video-container">
        <video autoplay  loop muted  class="bgvid">
            <source src="<?php echo esc_url($video );?>" type="video/mp4">
            <?php if(!empty($videoogg)) :?>
            <source src="<?php echo esc_url($videoogg );?>" type="video/ogg">
        <?php endif;?>
        </video>
    </div>
</div>
<div class="overlay" style="opacity:<?php echo esc_attr($parallax_inner_op );?>;"></div>