<?php
/**
 * Shortcode attributes
 * @var $atts
 * @var $el_class
 * @var $slideimg
 * Shortcode class
 * @var $this WPBakeryShortCode_Testimonials_Slider_Item
 */
$el_class = $slideimg = '';
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

?>
<div class="item <?php echo esc_attr($el_class );?>">
	<?php echo wp_get_attachment_image( $slideimg, 'full', false , array('class'=>'res-image') );?>
    <?php echo wpb_js_remove_wpautop($content,true);?>
</div>
