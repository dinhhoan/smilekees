<?php
$css = $el_class = $cat_ids = $order = $order_by = $ids = $ids_not = $posts_per_page = $show_pagination =  $columns_grid = $show_loadmore  = $lmore_items = $show_filter = $spacing = $click_action = '';
$parallax_img = $parallax_dir = $parallax_val = $show_decor = $decor_img = '';
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

if(is_front_page()) {
    $paged = (get_query_var('page')) ? get_query_var('page') : 1;
} else {
    $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
}

if(!empty($ids)){
    $ids = explode(",", $ids);
    $post_args = array(
        'post_type' => 'cthmenu',
        'paged' => $paged,
        'posts_per_page'=> $posts_per_page,
        'post__in' => $ids,
        'orderby'=> $order_by,
        'order'=> $order,
    );
}elseif(!empty($ids_not)){
    $ids_not = explode(",", $ids_not);
    $post_args = array(
        'post_type' => 'cthmenu',
        'paged' => $paged,
        'posts_per_page'=> $posts_per_page,
        'post__not_in' => $ids_not,
        'orderby'=> $order_by,
        'order'=> $order,
    );
}else{
    $post_args = array(
        'post_type' => 'cthmenu',
        'paged' => $paged,
        'posts_per_page'=> $posts_per_page,
        'orderby'=> $order_by,
        'order'=> $order,
    );
}

if(!empty($cat_ids)){
    $post_args['tax_query'][] = array(
        'taxonomy' => 'cthmenu_cat',
        'field' => 'term_id',
        'terms' => explode(',', $cat_ids),
    );
}



$css_classes = array(
    'lambert-menus-wrap',
    $el_class,
    vc_shortcode_custom_css_class( $css ),
);

$css_class = preg_replace( '/\s+/', ' ', implode( ' ', array_filter( $css_classes ) ) );

?>
<?php          
$menu_posts = new WP_Query($post_args);
if($menu_posts->have_posts()) : ?>
<div class="<?php echo esc_attr($css_class);?>">
<?php if($parallax_img != '') : ?>
    <?php 
    if(empty($parallax_val)) $parallax_val = 0; ?>
    <?php
    if($parallax_dir == 'left') : ?>
    <div class="menu-bg lbd" style="background-image:url(<?php echo wp_get_attachment_url( $parallax_img );?>)" data-top-bottom="transform: translateX(<?php echo esc_attr($parallax_val);?>px);" data-bottom-top="transform: translateX(<?php echo 0 - $parallax_val;?>px);"></div>
    <?php elseif($parallax_dir == 'right') : ?>
    <div class="menu-bg rbd" style="background-image:url(<?php echo wp_get_attachment_url( $parallax_img );?>)" data-top-bottom="transform: translateX(<?php echo 0-$parallax_val;?>px);" data-bottom-top="transform: translateX(<?php echo esc_attr($parallax_val);?>px);"></div>
    <?php endif; ?>
<?php endif; ?>
    <div class="container-menu">
        <?php if($show_decor == 'yes') : ?>
        <div class="separator color-separator"<?php if($decor_img != '') echo ' style="background-image:url('.wp_get_attachment_url( $decor_img ).');"' ;?>></div>
        <?php endif;?>
        <div class="mn-menu-holder">
            <div class="row">
            <?php while($menu_posts->have_posts()) : $menu_posts->the_post(); ?>
                <div class="col-md-<?php echo esc_attr($columns_grid );?>">
            <?php $hot_deal = get_post_meta( get_the_ID(), '_cmb_menu_promo_label', true ); 
                if($hot_deal != ''){
            ?>
                    <div class="mn-menu-item hot-deal">
                        <span class="hot-desc"><?php echo esc_html( $hot_deal );?></span>
            <?php }else{ ?>
                    <div class="mn-menu-item">
            <?php } ?>
                        <div class="mn-menu-item-details">
                        <?php 
                        if($click_action == 'popup') : ?>
                            <div class="mn-menu-item-desc"><a href="<?php echo wp_get_attachment_url( get_post_thumbnail_id( ) );?>" class="image-popup"><?php the_title( );?></a></div>
                        <?php else : ?>
                            <div class="mn-menu-item-desc"><a href="javascript:void(0)" class="goto-menu-page"><?php the_title( );?></a></div>
                        <?php endif;?>
                            <div class="mn-menu-item-dot"></div>
                            <div class="mn-menu-item-prices">
                                <div class="mn-menu-item-price"><?php echo get_post_meta( get_the_ID(), '_cmb_menu_price', true );?></div>
                            </div>
                        </div>
                        <?php the_excerpt();?>
                    </div>
                </div>
            <?php endwhile; ?>
            </div>
        </div>
        <?php if($show_decor == 'yes') : ?>
        <div class="bold-separator">
            <span></span>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php endif; ?>

