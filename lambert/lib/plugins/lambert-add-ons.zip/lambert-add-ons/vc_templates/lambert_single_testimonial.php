<?php

$el_class = $css = $id = $show_avatar = $show_title = $show_rating = '';
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$css_classes = array(
    'single-testim-holder',
    $el_class,
    vc_shortcode_custom_css_class( $css ),
);
$css_class = preg_replace( '/\s+/', ' ', implode( ' ', array_filter( $css_classes ) ) );


if(!empty($id)){
	$args = array(
	    'post_type'		 => 'testimonial',
	    'p' => intval($id),
	    
	);
}else{
	$args = array(
	    'post_type'		 => 'testimonial',
	    'posts_per_page' => 1,
	    
	);
}
$testimonial = new WP_Query($args);

?>
<?php if($testimonial->have_posts()) {       ?>
<div class="<?php echo esc_attr($css_class ); ?>">

        <?php        
        while($testimonial->have_posts()) : $testimonial->the_post();  
        ?>
            <div class="testi-item">
            <?php if($show_avatar == 'yes') :?>
                <?php the_post_thumbnail('thumbnail' ); ?>
            <?php endif;?>
            <?php if($show_title === 'yes') :?>
                <h3><?php the_title( );?></h3>
            <?php endif;?>
                <?php 
                if($show_rating === 'yes') :
                    $rated = get_post_meta(get_the_id(), '_cmb_testim_rate', true ); 
                    if($rated != '' && $rated != 'no'){
                        $ratedval = floatval($rated);
                        echo '<ul class="star-rating">';
                        for ($i=1; $i <= 5; $i++) { 
                            if($i <= $ratedval){
                                echo '<li><i class="fa fa-star"></i></li>';
                            }else{
                                if($i - 0.5 == $ratedval){
                                    echo '<li><i class="fa fa-star-half-o"></i></li>';
                                }else{
                                	echo '<li><i class="fa fa-star-o"></i></li>';
                                }
                            }
                            
                        }
                        echo '</ul>';
                    }else{
                        esc_html_e('Not Rated','lambert-add-ons' );
                    }

                endif;

                ?>
                <?php the_content( ); ?>
            </div>

        <?php 
        endwhile; ?>

</div>

<?php
}

/* Restore original Post Data */
wp_reset_postdata();

?>