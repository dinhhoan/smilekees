<?php

$el_class = $css = $title_text = $subtitle_text = $sub_decor = $show_decor = $decor_img = '';
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$css_classes = array(
    'section-title',
    $el_class,
    vc_shortcode_custom_css_class( $css ),
);
$css_class = preg_replace( '/\s+/', ' ', implode( ' ', array_filter( $css_classes ) ) );

?>
<div class="<?php echo esc_attr($css_class );?>">
<?php if(!empty($title_text)):?>
    <h3><?php echo esc_html($title_text);?></h3>
    <?php endif;?>
    <?php if($subtitle_text != ''):?>
    <h4 class="<?php echo ($sub_decor == 'yes')? 'decor-title' : 'no-decor-title';?>"><?php echo esc_html($subtitle_text);?></h4>
    <?php endif;?>
    <?php if($show_decor == 'yes') : ?>
    <div class="separator color-separator"<?php if($decor_img != '') echo ' style="background-image:url('.wp_get_attachment_url( $decor_img ).');"' ;?>></div>
    <?php endif;?>
    <?php echo wpb_js_remove_wpautop($content,true);?>
</div>
<div class="clearfix"></div>
