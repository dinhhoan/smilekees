<?php
/**
 * Shortcode attributes
 * @var $atts
 * @var $el_class
 * @var $bgimg
 * Shortcode class
 * @var $this WPBakeryShortCode_Cth_Image_Parallax
 */
$el_class = $bgimg = $parallax_inner_op = $parallax_inner_val = '';
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );
if ($parallax_inner_val == '') {
    $parallax_inner_val = 0;
}
?>
<div class="bg bg-parallax <?php echo esc_attr($el_class );?>" 
<?php if(!empty($bgimg)) : ?>
  style="background-image:url(<?php echo wp_get_attachment_url($bgimg );?>);"
<?php endif;?>
 data-top-bottom="transform: translateY(<?php echo esc_attr($parallax_inner_val);?>px);" data-bottom-top="transform: translateY(<?php echo 0-$parallax_inner_val;?>px);"></div>
<div class="overlay" style="opacity:<?php echo esc_attr($parallax_inner_op );?>;"></div>