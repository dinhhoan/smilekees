<?php
/**
 * Shortcode attributes
 * @var $atts
 * @var $el_class
 * @var $day
 * @var $name
 * @var $price
 * @var $discount
 * Shortcode class
 * @var $this WPBakeryShortCode_Cth_Deal
 */
$el_class = $day = $name = $price = $discount = '';
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );
?>
<div class="promotion-item <?php echo esc_attr($el_class );?>">
    <div class="promotion-title">
    <?php if(!empty($day)) :?>
        <h4><?php echo esc_attr($day );?></h4>
    <?php endif;?>
    <?php if(!empty($name)) :?>
        <span><?php echo esc_attr($name );?></span>
    <?php endif;?>
    </div>
    <div class="promotion-details">
    <?php if(!empty($content)) :?>
        <div class="promotion-desc"><?php echo wp_kses_post($content );?></div>
    <?php endif;?>
        <div class="promotion-dot deal-dot"></div>
        <div class="promotion-prices">
        <?php if(!empty($price)) :?>
          <span class="promotion-price"><?php echo esc_attr($price );?></span>
        <?php endif;?>
        <?php if(!empty($discount)) :?>
          <span class="promotion-discount"><?php echo esc_attr($discount );?></span>
        <?php endif;?>
        </div>
    </div>
</div>