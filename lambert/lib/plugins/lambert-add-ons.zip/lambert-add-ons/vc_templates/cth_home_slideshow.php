<?php
/**
 * Shortcode attributes
 * @var $atts
 * @var $el_class
 * @var $bgimgs
 * @var $opacity
 * Shortcode class
 * @var $this WPBakeryShortCode_Cth_Home_Slideshow
 */
$el_class = $bgimgs = $opacity = '';
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );
?>
<div class="content full-height hero-content <?php echo esc_attr($el_class );?>">
	<?php if(!empty($bgimgs)) : ?>
	    <div class="slideshow-container" data-top-bottom="transform: translateY(300px);" data-bottom-top="transform: translateY(-300px);">	
		    <div class="slides-container">
		    <?php
		    	$bgimgs = explode(",", $bgimgs);
		    	foreach ($bgimgs as $key => $bg) { ?>
		    		<div class="bg" style="background-image: url(<?php echo wp_get_attachment_url($bg );?>)"></div>
		    <?php 
		    	}
		    ?>
	        </div>
	    </div>
	<?php endif;?>
        <?php echo wp_kses_post(rawurldecode(base64_decode(strip_tags($content))) );?>
</div>