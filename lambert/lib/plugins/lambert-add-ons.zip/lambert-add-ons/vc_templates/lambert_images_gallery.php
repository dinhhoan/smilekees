<?php
$css = $el_class = $galleryimgs = $posts_per_page = $columns_grid = $show_loadmore = $lmore_items = $spacing = $enable_gallery = $show_filter = $filter_list = '';
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );


$css_classes = array(
    'gallery-items popup-gallery',
    $el_class,
    //vc_shortcode_custom_css_class( $css ),
    $columns_grid.'-coulms',
    'grid-'.$spacing.'-pad'
);
//if($enable_gallery == 'yes') $css_classes[] = 'popup-gallery';

$css_class = preg_replace( '/\s+/', ' ', implode( ' ', array_filter( $css_classes ) ) );

if(!empty($galleryimgs)){
	$lmore_data = false;
    if($show_loadmore == 'yes'){
        $lmore_data = array();
        $lmore_data['images'] = $galleryimgs;
        $lmore_data['loaded'] = $loaded;
        $lmore_data['action'] = 'lambert_lm_gallery';
        $lmore_data['lmore_items'] = $lmore_items;

    }
    $gal_imgs = explode(",", $galleryimgs);
    if(!empty($gal_imgs)) : 
?>

<section class="no-padding <?php echo vc_shortcode_custom_css_class( $css );?>">
    <div class="containers container-gallery">

		<?php    
		if($show_filter == 'yes' && $filter_list != '') :
		?>
		<div class="gallery-filters">
            <a href="#" class="gallery-filter gallery-filter-active"  data-filter="*"><?php esc_html_e('All','lambert-add-ons' );?></a>		
            <?php 
            $filter_list = explode("|", $filter_list);
	        foreach ($filter_list as  $fil) {
	        ?>
            <a href="#" class="gallery-filter " data-filter=".filter-<?php echo sanitize_title($fil ); ?>"><?php echo esc_html($fil ); ?></a>
            
            <?php } ?>
        </div>
        <div class="bold-separator"><span></span></div>
		<?php
		endif; //end showfillter
		?>
		<div class="gallery-images-grid-wrap">
		    <div class="<?php echo esc_attr($css_class );?>"
				<?php if($show_loadmore == 'yes' && count($gal_imgs) > $loaded ):?>
		         data-lm-request="<?php echo esc_url(admin_url( 'admin-ajax.php' ) ) ;?>"
		         data-lm-nonce="<?php echo wp_create_nonce( 'lambert_lm_gallery' ); ?>"
		         data-lm-settings="<?php echo esc_attr(json_encode($lmore_data) ); ?>"
		        <?php endif;?>
		    
		    >

		            <div class="grid-sizer"></div>
		            <div class="grid-sizer-second"></div>
		            <div class="grid-sizer-three"></div>
		            <?php foreach ($gal_imgs as $key => $img_id) { 
		                if($key < $loaded) {
		                	$at_img = get_post($img_id);

		                    $at_tit = $at_img->post_title;
		                    $at_cap = $at_img->post_excerpt;
		                    $at_des = $at_img->post_content;

		                    $item_w = ' image-id-'.$img_id;

		                    if( preg_match_all('/-f-([^-]*)-f-/m', $at_cap, $matches ) !== false ){
		                        if(!empty($matches[1])){
		                            foreach ($matches[1] as $fil) {
		                                $item_w .= ' filter-'.sanitize_title( $fil );
		                            }
		                        }
		                    }

		                    $image_size = 'lambert-gallery-one';

		                    if(strpos($at_des, "size-two") !== false){
			                    $item_w .= ' gallery-item-second';
			                    $image_size = 'lambert-gallery-second';
			                }
			                if(strpos($at_des, "size-three") !== false){
			                    $item_w .= ' gallery-item-three';
			                    $image_size = 'lambert-gallery-three';
			                }

			        ?>
			        	<div class="gallery-item <?php echo esc_attr( $item_w );?>">
							<div class="grid-item-holder">
						        <div class="box-item">

						            <a href="<?php echo esc_url(wp_get_attachment_url( $img_id ) );?>"  class="por-linksss" title="<?php echo esc_attr($at_tit );?>">
						            	<span class="overlay"></span>
								        <i class="fa fa-image"></i>
							            <?php echo wp_get_attachment_image($img_id, $image_size ); ?>
							            
						            </a>
						        </div>
						    </div>
						</div>
			        <?php
			        		}
			            }
			        ?>

		    </div>
			<?php if($show_loadmore == 'yes' && count($gal_imgs) > $loaded ):?>
		    <div class="gallery-lmore-holder">
		        <a class="gallery-load-more" data-click="1" data-remain="yes" href="#"><?php echo wp_kses(__('<i class="fa fa-spinner fa-pulse fa-3x fa-fw"></i><span class="sr-only">Loading...</span>','lambert-add-ons'), array('i'=>array('class'=>array()),'span'=>array('class'=>array()),) );?></a>
		    </div>
		    <?php endif;?>
		</div>

	</div>
</section>
<?php
    endif;
}

