<?php
/**
 * @var $this WPBakeryShortCode_Lambert_Counter
 */
$el_class = $number = '';
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

?>
<div class="milestone-counter <?php echo esc_attr($el_class ); ?>">
    <div class="stats animaper">
        <div class="num" data-content="<?php echo esc_attr($number );?>" data-num="<?php echo esc_attr($number );?>">0</div>
    </div>
</div>
<?php echo wpb_js_remove_wpautop($content);?>