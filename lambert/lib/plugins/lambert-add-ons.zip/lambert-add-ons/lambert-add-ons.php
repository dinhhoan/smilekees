<?php
/*
Plugin Name: Lambert Add-Ons
Plugin URI: https://demowp.cththemes.com/lambert/
Description: A custom plugin for Lambert - Restaurant / Cafe / Pub WordPress Theme
Version: 2.5.1
Author: CTHthemes
Author URI: http://themeforest.net/user/cththemes
Text Domain: lambert-add-ons
Domain Path: /languages/
Copyright: ( C ) 2014 - 2019 cththemes.com . All rights reserved.
License: GNU General Public License version 3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html
*/

if ( ! defined('ABSPATH') ) {
    die('Please do not load this file directly!');
}

if ( ! defined( 'BBT_PLUGIN_FILE' ) ) {
    define( 'BBT_PLUGIN_FILE', __FILE__ );
}

if ( ! class_exists( 'Lambert_Addons' ) ) {
    include_once dirname( __FILE__ ) . '/includes/class-addons.php';
}

function BBT_ADO() {
    return Lambert_Addons::getInstance();
}

BBT_ADO();



